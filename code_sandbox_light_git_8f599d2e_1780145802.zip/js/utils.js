/* ======================================================
   utils.js — Shared helpers
   ====================================================== */

const API = {
  async get(table, params = {}) {
    const qs = new URLSearchParams({ limit: 500, ...params }).toString();
    const r = await fetch(`tables/${table}?${qs}`);
    return r.json();
  },
  async getOne(table, id) {
    const r = await fetch(`tables/${table}/${id}`);
    return r.json();
  },
  async post(table, data) {
    const r = await fetch(`tables/${table}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return r.json();
  },
  async put(table, id, data) {
    const r = await fetch(`tables/${table}/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return r.json();
  },
  async patch(table, id, data) {
    const r = await fetch(`tables/${table}/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return r.json();
  },
  async delete(table, id) {
    await fetch(`tables/${table}/${id}`, { method: 'DELETE' });
  }
};

// Format currency
function fmt(n) { return '₹' + parseFloat(n || 0).toFixed(2); }
function fmtN(n) { return parseFloat(n || 0).toLocaleString('en-IN'); }

// Today's date string YYYY-MM-DD
function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

// Date display
function fmtDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

// Generate invoice number
function genInvoiceNo(prefix = 'INV') {
  const d = new Date();
  return `${prefix}-${d.getFullYear()}${String(d.getMonth()+1).padStart(2,'0')}${String(d.getDate()).padStart(2,'0')}-${String(Math.floor(Math.random()*9000)+1000)}`;
}

// Avatar color from name
const AVATAR_COLORS = ['#5b4fcf','#3b82f6','#22c55e','#f97316','#a855f7','#14b8a6','#ef4444','#eab308'];
function avatarColor(name = '') {
  let h = 0;
  for (let c of name) h = (h * 31 + c.charCodeAt(0)) & 0xffff;
  return AVATAR_COLORS[h % AVATAR_COLORS.length];
}
function avatarInitials(name = '') {
  const parts = name.trim().split(/\s+/);
  return (parts[0]?.[0] || '') + (parts[1]?.[0] || '');
}

// Category label map
const CAT_LABELS = {
  attar_bulk: 'Attar Bulk',
  attar_variant: 'Attar Variant',
  mobile_accessory: 'Mobile Accessory',
  cyber_service: 'Cyber Service',
  bottle: 'Bottle',
  other: 'Other'
};
function catLabel(c) { return CAT_LABELS[c] || c; }

// Badge HTML
function catBadge(cat) {
  const map = {
    attar_bulk: 'badge-purple', attar_variant: 'badge-blue',
    mobile_accessory: 'badge-orange', cyber_service: 'badge-teal',
    bottle: 'badge-gray', other: 'badge-gray'
  };
  return `<span class="badge ${map[cat] || 'badge-gray'}">${catLabel(cat)}</span>`;
}

// Escape HTML
function esc(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

// Safe JSON parse
function safeJSON(s, fallback = []) {
  try { return JSON.parse(s); } catch { return fallback; }
}

// ===== MODAL =====
const Modal = {
  open(title, html, onSave) {
    document.getElementById('modal-title').textContent = title;
    document.getElementById('modal-body').innerHTML = html;
    document.getElementById('modal-overlay').classList.remove('hidden');
    this._onSave = onSave;
  },
  close() {
    document.getElementById('modal-overlay').classList.add('hidden');
    document.getElementById('modal-body').innerHTML = '';
    this._onSave = null;
  },
  _onSave: null
};

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('modal-close').addEventListener('click', () => Modal.close());
  document.getElementById('modal-overlay').addEventListener('click', e => {
    if (e.target === document.getElementById('modal-overlay')) Modal.close();
  });
});

// Toast notification
function toast(msg, type = 'success') {
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i> ${esc(msg)}`;
  document.body.appendChild(t);
  setTimeout(() => t.classList.add('show'), 10);
  setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 300); }, 3000);
}

// Inject toast CSS once
const toastStyle = document.createElement('style');
toastStyle.textContent = `
  .toast {
    position:fixed; bottom:24px; right:24px; z-index:9999;
    background:#1e1b4b; color:#fff;
    padding:12px 20px; border-radius:10px;
    font-size:.82rem; font-weight:600;
    display:flex; align-items:center; gap:8px;
    box-shadow:0 4px 16px rgba(0,0,0,.2);
    transform:translateY(80px); opacity:0;
    transition:all .3s ease;
    max-width:320px;
  }
  .toast.show { transform:translateY(0); opacity:1; }
  .toast-success i { color:#22c55e; }
  .toast-error   i { color:#ef4444; }
  .toast-info    i { color:#3b82f6; }
`;
document.head.appendChild(toastStyle);

// Confirm dialog
function confirm2(msg) {
  return new Promise(resolve => {
    const overlay = document.createElement('div');
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9000;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(2px)';
    overlay.innerHTML = `
      <div style="background:#fff;border-radius:12px;padding:28px 32px;max-width:360px;width:90%;box-shadow:0 12px 32px rgba(0,0,0,.2);text-align:center">
        <i class="fas fa-question-circle" style="font-size:2rem;color:#f97316;margin-bottom:12px"></i>
        <p style="font-size:.9rem;color:#1a202c;margin-bottom:20px;line-height:1.5">${esc(msg)}</p>
        <div style="display:flex;gap:12px;justify-content:center">
          <button id="conf-no" style="padding:8px 24px;border-radius:8px;border:1px solid #e2e8f0;font-size:.85rem;font-weight:600;cursor:pointer">Cancel</button>
          <button id="conf-yes" style="padding:8px 24px;border-radius:8px;background:#ef4444;color:#fff;font-size:.85rem;font-weight:600;cursor:pointer;border:none">Delete</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    overlay.querySelector('#conf-yes').onclick = () => { overlay.remove(); resolve(true); };
    overlay.querySelector('#conf-no').onclick  = () => { overlay.remove(); resolve(false); };
  });
}

# 🕌 نوری — Noori Cyber Cafe & Noori Perfume
## Smart Shop Manager — Complete Guide

---

## ✅ What's Built & Working

### 🎨 Branding & Animations
- **Noori-branded splash screen** with Arabic calligraphy (نوری), animated rings, and loading dots
- **Animated welcome banner** on Dashboard with floating icons (🧪 🖨️ 📱) and Arabic Bismillah
- **Staggered stat card entrance** animations (cards fly in one by one)
- **Page transition animations** — every page slides in smoothly
- **Sidebar nav hover effects** with animated left-border indicator
- **"NEW" badge** on new features (glowing orange pill)
- **Noori branded receipt** with Arabic شکریہ (thank you) and Urdu tagline
- **Shimmer effect** on the checkout button
- **Pulsing green dot** on the shop badge in topbar
- **Bell ring animation** on hover
- **Floating product icon bubbles** on welcome banner

### 📦 Smart Inventory (18 sample items pre-loaded)
- Bulk attar tracker (ml/tola auto-deduction)
- Variant management (3ml, 6ml, 12ml bottles)
- Low-stock alerts with notification bell
- Stock adjustment modal

### 🛒 POS / Billing
- Hybrid cart (attars + mobile accessories + cyber services)
- Customer linking, loyalty points, Khata billing
- Custom volume entry for bulk attars
- Noori-branded printable receipts

### 🧾 Purchases & Suppliers (4 sample suppliers)
- Full purchase log with line items
- Supplier directory with contact cards

### 👥 Customers & Khata (4 sample customers)
- Loyalty points, khata balance
- WhatsApp reminder one-click
- Full purchase history

### 🧪 Perfume Creator
- Custom blend logger with % bar
- Attach to customer profile
- Searchable recipe library

### 💸 Daily Expenses ⭐ NEW
- Log Rent, Electricity, Internet, Salary, etc.
- Today / Week / Month summary cards
- Filter by date and category

### 📝 Quick Notes ⭐ NEW
- Urgent / Normal / Info priority sticky notes
- Mark as Done with one click
- Staff reminders & to-do board

### 📈 Analytics
- Revenue trend, category split, top products
- Payment method breakdown
- Filter by 7 / 30 / 90 / 365 days

---

## 📱 HOW TO USE THE APP — Step by Step

### STEP 1 — First Time Setup
1. Open the app → a splash screen shows **Noori** for 2 seconds
2. You'll see a popup: **"🚀 Load Samples"** — click it to fill demo data
3. 18 inventory items, 4 suppliers, 4 customers, sample expenses & notes will appear

### STEP 2 — Add Your Real Products
1. Click **Inventory** in the left sidebar
2. Click **+ Add Item**
3. For bulk attar: Category = "Attar Bulk", Unit = "ml" or "tola"
4. For ready bottles: Category = "Attar Variant", add Variant Label like "6ml Roll-on"
5. For phone accessories: Category = "Mobile Accessory", Unit = "piece"
6. For printing/lamination: Category = "Cyber Service", Unit = "service"
7. Set **Low-Stock Alert** number (e.g., 50ml for bulk attar)

### STEP 3 — Make a Sale (POS)
1. Click **POS / Billing** in sidebar
2. Search for a product OR click the product card
3. For bulk attar (ml/tola): A popup asks "How many ml?" — enter the amount
4. For other items: Just click to add to cart
5. Optional: Search customer name to attach loyalty points
6. Set payment: Cash / UPI / Card / Khata
7. Click **Complete Sale** — stock auto-deducts, receipt pops up

### STEP 4 — Add Suppliers & Log Purchases
1. Click **Suppliers** → **+ Add Supplier** with phone number
2. Click **Purchases** → **+ New Purchase** to log what you bought and how much you paid
3. Set payment status: Paid / Partial / Pending

### STEP 5 — Manage Customers & Khata
1. Click **Customers** → **+ Add Customer** with phone number
2. When a customer buys on credit → choose "Khata" in POS payment
3. To collect payment: Click the red **"Collect"** button on customer card
4. To send reminder: Click the green **WhatsApp** button → message auto-fills!

### STEP 6 — Create Perfume Recipes
1. Click **Perfume Creator**
2. Enter recipe name (e.g., "Noori Eid Special")
3. Click **+ Add Ingredient**, select base attars from your inventory
4. Enter % for each (must total 100%)
5. Attach to a customer profile if it's a custom order
6. Click **Save Recipe** — find it anytime by customer name

### STEP 7 — Log Daily Expenses
1. Click **Daily Expenses** (Tools section in sidebar)
2. Click **+ Log Expense**
3. Select: Rent, Electricity, Internet, Salary, etc.
4. See Today / Week / Month summary at the top

### STEP 8 — Quick Notes & Reminders
1. Click **Quick Notes**
2. Click **+ New Note**
3. Choose priority: 🔴 Urgent, 🟡 Normal, 🔵 Info
4. When done, click ✓ to mark complete

### STEP 9 — View Analytics
1. Click **Analytics**
2. Choose period: Last 7 / 30 / 90 / 365 days
3. See which category makes the most money

---

## 🚀 HOW TO PUBLISH (Make it Live Online)

### Method — Use the Publish Tab (Easiest!)
1. Look at the **top of this page** — find the **"Publish"** tab
2. Click **Publish**
3. Your app gets a live URL like: `https://your-project.genspark.site`
4. **Share this link** with anyone — they can use it on phone or computer
5. Works on **any browser** — Chrome, Safari, Firefox

### After Publishing:
- Bookmark the URL on your phone's home screen for quick access
- Add it to your laptop/desktop bookmarks bar
- Share with staff so they can use it too
- All data is saved in the cloud — no data loss!

---

## 💡 10 SUGGESTED FEATURES TO ADD NEXT

| # | Feature | Why it's useful |
|---|---------|----------------|
| 1 | **GST Invoice Generator** | Print proper GST bills for business customers |
| 2 | **WhatsApp Receipt API** | Actually send bills via WhatsApp Business automatically |
| 3 | **Monthly P&L Report** | Revenue − Expenses = Net Profit per month |
| 4 | **Staff Login Roles** | Separate access for you (owner) and your staff |
| 5 | **Bottle Label Maker** | Print custom "Noori Perfume" labels for 6ml/12ml bottles |
| 6 | **Stock Expiry Alerts** | Warn when bulk attar was purchased more than 6 months ago |
| 7 | **Barcode Print & Scan** | Print barcodes for products, scan with phone camera |
| 8 | **Customer Birthday Wishes** | Auto-remind when a customer's birthday is coming |
| 9 | **Discount Coupons / Offers** | Create "Eid 10% Off" coupons with codes |
| 10 | **Daily Cash Register Summary** | Print end-of-day summary: total cash + UPI + khata |

---

## 🗂️ File Structure
```
index.html              — Main app shell
css/
  style.css             — Full design system
  animations.css        — All Noori animations & splash screen
js/
  utils.js              — API, helpers, modal, toast
  app.js                — Navigation, splash, receipt, seed data
  inventory.js          — Inventory management
  pos.js                — POS billing & cart
  purchases.js          — Purchase logs
  suppliers.js          — Supplier directory
  customers.js          — Customer management & loyalty
  khata.js              — Khata/credit ledger
  perfume.js            — Perfume blend creator
  expenses.js           — Daily expense tracker (NEW)
  notes.js              — Quick notes board (NEW)
  analytics.js          — Charts & reports
  dashboard.js          — Dashboard stats & charts
```

---

## 🗄️ Database Tables
| Table | Purpose |
|-------|---------|
| `inventory` | All products & stock levels |
| `sales` | Every sale transaction |
| `purchases` | Wholesale purchase records |
| `suppliers` | Supplier contacts |
| `customers` | Customer profiles + loyalty + khata |
| `khata_ledger` | Credit/debit ledger entries |
| `perfume_recipes` | Custom blend recipes |
| `expenses` | Daily shop expenses |
| `shop_notes` | Staff notes & reminders |

---

*Built with ❤️ for Noori Cyber Cafe & Noori Perfume — نوری*

/* ======================================================
   dashboard.js — Dashboard Stats & Charts
   ====================================================== */

let dashCharts = {};

async function loadDashboard() {
  const today = todayStr();
  const monthStart = today.slice(0, 7) + '-01';

  const [salesRes, inventoryRes, customersRes] = await Promise.all([
    API.get('sales'),
    API.get('inventory'),
    API.get('customers')
  ]);
  // Animate stat cards on reload
  document.querySelectorAll('.stat-card').forEach((c, i) => {
    c.style.setProperty('--i', i);
    c.classList.remove('anim-card');
    void c.offsetWidth; // force reflow
    c.classList.add('anim-card');
  });

  const allSalesData = salesRes.data || [];
  const inventoryData = (inventoryRes.data || []).filter(i => i.active !== false);
  const customersData = (customersRes.data || []).filter(c => c.active !== false);

  // Today's sales
  const todaySales = allSalesData.filter(s => (s.sale_date || '').slice(0, 10) === today);
  const todayRevenue = todaySales.reduce((s, x) => s + (x.total_amount || 0), 0);

  // Month sales
  const monthSales = allSalesData.filter(s => (s.sale_date || '') >= monthStart);
  const monthRevenue = monthSales.reduce((s, x) => s + (x.total_amount || 0), 0);

  // Stats
  document.getElementById('stat-today-sales').textContent = fmt(todayRevenue);
  document.getElementById('stat-month-orders').textContent = monthSales.length;
  document.getElementById('stat-customers').textContent = customersData.length;
  document.getElementById('stat-month-revenue').textContent = fmt(monthRevenue);

  // Low stock
  const lowStock = inventoryData.filter(i => i.unit !== 'service' && i.stock_qty <= (i.low_stock_threshold || 5));
  document.getElementById('stat-low-stock').textContent = lowStock.length;

  // Khata
  const khataTotal = customersData.reduce((s, c) => s + (c.khata_balance || 0), 0);
  document.getElementById('stat-khata').textContent = fmt(khataTotal);

  // Low stock dashboard list
  renderDashboardLowStock(lowStock);

  // Top items
  renderTopItems(allSalesData.filter(s => (s.sale_date || '') >= monthStart));

  // Charts
  drawDashSalesChart(allSalesData);
  drawDashCategoryChart(allSalesData.filter(s => (s.sale_date || '') >= monthStart));
}

function renderDashboardLowStock(items) {
  const el = document.getElementById('dashboard-low-stock');
  if (!items.length) {
    el.innerHTML = `<p class="empty-msg">All items well stocked 👍</p>`;
    return;
  }
  const limited = items.slice(0, 8);
  el.innerHTML = `<div class="list-plain">
    ${limited.map(i => `<div class="list-plain-item">
      <div>
        <div style="font-weight:600;font-size:.83rem">${esc(i.name)}</div>
        <div style="font-size:.72rem;color:var(--text-3)">${catLabel(i.category)}</div>
      </div>
      <div style="text-align:right">
        <div class="stock-${i.stock_qty <= 0 ? 'low' : 'warn'}">${fmtN(i.stock_qty)} ${i.unit}</div>
        <div style="font-size:.7rem;color:var(--text-3)">Alert: ${i.low_stock_threshold} ${i.unit}</div>
      </div>
    </div>`).join('')}
  </div>`;
}

function renderTopItems(monthSales) {
  const el = document.getElementById('top-items-list');
  const productMap = {};
  monthSales.forEach(s => {
    const items = safeJSON(s.items, []);
    items.forEach(i => {
      const key = i.name;
      if (!productMap[key]) productMap[key] = { revenue: 0, qty: 0, cat: i.category };
      productMap[key].revenue += i.price * i.qty;
      productMap[key].qty += i.qty;
    });
  });
  const sorted = Object.entries(productMap).sort((a, b) => b[1].revenue - a[1].revenue).slice(0, 6);
  if (!sorted.length) {
    el.innerHTML = `<p class="empty-msg">No sales this month yet.</p>`;
    return;
  }
  el.innerHTML = `<div class="list-plain">
    ${sorted.map(([name, data], idx) => `<div class="list-plain-item">
      <div style="display:flex;align-items:center;gap:10px">
        <span class="list-rank">${idx + 1}</span>
        <div>
          <div style="font-weight:600;font-size:.83rem">${esc(name)}</div>
          <div style="font-size:.7rem;color:var(--text-3)">${catLabel(data.cat)}</div>
        </div>
      </div>
      <div style="font-weight:800;color:var(--primary)">${fmt(data.revenue)}</div>
    </div>`).join('')}
  </div>`;
}

function drawDashSalesChart(allSales) {
  const labels = [];
  const data = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    labels.push(d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }));
    const total = allSales
      .filter(s => (s.sale_date || '').slice(0, 10) === key)
      .reduce((t, s) => t + (s.total_amount || 0), 0);
    data.push(parseFloat(total.toFixed(2)));
  }

  const existing = Chart.getChart('salesChart');
  if (existing) existing.destroy();

  const ctx = document.getElementById('salesChart').getContext('2d');
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'Sales (₹)',
        data,
        backgroundColor: 'rgba(91,79,207,.8)',
        borderRadius: 8,
        borderSkipped: false
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } }
    }
  });
}

function drawDashCategoryChart(monthSales) {
  const catMap = {};
  monthSales.forEach(s => {
    const items = safeJSON(s.items, []);
    items.forEach(i => {
      const c = i.category || 'other';
      catMap[c] = (catMap[c] || 0) + i.price * i.qty;
    });
  });

  const existing = Chart.getChart('categoryChart');
  if (existing) existing.destroy();

  if (!Object.keys(catMap).length) return;

  const ctx = document.getElementById('categoryChart').getContext('2d');
  new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: Object.keys(catMap).map(c => catLabel(c)),
      datasets: [{
        data: Object.values(catMap).map(v => parseFloat(v.toFixed(2))),
        backgroundColor: ['#5b4fcf','#3b82f6','#22c55e','#f97316','#a855f7','#14b8a6'],
        borderWidth: 2, borderColor: '#fff'
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { position: 'bottom', labels: { font: { size: 11 }, padding: 10 } } }
    }
  });
}
